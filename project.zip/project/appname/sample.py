from flask import Flask, render_template, request, flash, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/e_health'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)

@app.route('/')
def index():
   return render_template('welcome.html')
@app.route('/login')
def log():
   return render_template('log.html')  
@app.route('/register')
def reg():
   return render_template('reg2.html')	
@app.route('/dregister')
def dreg():
   return render_template('dreg2.html')						

@app.route('/admin')
def admin():
   return render_template('admin/admin.html')
@app.route('/adoc')
def adoc():
   return render_template('admin/adoc.html')
@app.route('/ad')
def ad():
   return render_template('admin/ad.html')
@app.route('/vdoc')
def vdoc():
   return render_template('admin/vdoc.html',adoc=adoc.query.all())
@app.route('/vd')
def vd():
   return render_template('admin/vd.html',ad=ad.query.all())
@app.route('/vp')
def vp():
   return render_template('admin/vp.html',register=register.query.all())
@app.route('/vf')
def vf():
   return render_template('admin/vf.html',feedback=feedback.query.all())
@app.route('/vc')
def vc():
   return render_template('admin/vc.html',contact=contact.query.all())

@app.route('/home')
def home():
   return render_template('user/home1.html')
@app.route('/details/<name>')
def details(name):
   return render_template('user/details.html',register=register.query.filter_by(username='%s'%name))
@app.route('/search')
def search():
   return render_template('user/search.html')
@app.route('/search_details/<name>')
def search_details(name):
   return render_template('user/search_view.html',adoc=adoc.query.filter_by(name='%s'%name))
@app.route('/m_app')
def m_app():
   return render_template('user/m_app.html',contact=contact.query.all())
@app.route('/prediction')
def prediction():
   return render_template('user/prediction.html')
@app.route('/prediction_details/<name>')
def prediction_details(name):
   return render_template('user/prediction_view.html',ad=ad.query.filter_by(diseases_name='%s'%name))
@app.route('/rdoc')
def rdoc():
   return render_template('user/rdoc_view.html',adoc=adoc.query.all())
@app.route('/feedback')
def feedback():
   return render_template('user/feedback.html')
@app.route('/contact')
def contact():
   return render_template('user/contact.html')

@app.route('/dh')
def home2():
   return render_template('doctor/home.html')
@app.route('/dd')
def details1():
   return render_template('doctor/details.html')
@app.route('/dr')
def record():
   return render_template('doctor/patientrcrd.html',register=register.query.all())
@app.route('/df')
def feedback1():
   return render_template('doctor/feedback.html',feedback=feedback.query.all())
@app.route('/dc')
def contact1():
   return render_template('doctor/contact.html',contact=contact.query.all())

class register(db.Model):
	id = db.Column('reg_id', db.Integer, primary_key = True)
	name = db.Column(db.String(200))
	email = db.Column(db.String(200))
	username = db.Column(db.String(200)) 
	password = db.Column(db.String(10))
	r_password = db.Column(db.String(10))
	dob1 = db.Column(db.String(100))
	dob2 = db.Column(db.String(100))
	dob3 = db.Column(db.String(100))
	gender = db.Column(db.String(10))
	phn = db.Column(db.String(100))
	def __init__(self, name, email, username, password, r_password, dob1, dob2, dob3, gender, phn):
		self.name = name
		self.email = email
		self.username = username
		self.password = password
		self.r_password = r_password
		self.dob1 = dob1
		self.dob2 = dob2
		self.dob3 = dob3
		self.gender = gender
		self.phn = phn
	@app.route('/register', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['r_password'] or not request.form['dob1'] or not request.form['dob2'] or not request.form['dob3'] or not request.form['gender'] or not request.form['phn']:
				flash('Please enter all the fields', 'error')
			else:
				reg = register(request.form['name'], request.form['email'], request.form['username'], request.form['password'], request.form['r_password'], request.form['dob1'], request.form['dob2'], request.form['dob3'], request.form['gender'], request.form['phn'])			 
				db.session.add(reg)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('log'))
		return render_template('register.html')

class dregister(db.Model):
	id = db.Column('dreg_id', db.Integer, primary_key = True)
	name = db.Column(db.String(200))
	email = db.Column(db.String(200))
	degree = db.Column(db.String(200))
	username = db.Column(db.String(200)) 
	password = db.Column(db.String(10))
	r_password = db.Column(db.String(10))
	dob1 = db.Column(db.String(100))
	dob2 = db.Column(db.String(100))
	dob3 = db.Column(db.String(100))
	gender = db.Column(db.String(10))
	phn = db.Column(db.String(100))
	def __init__(self, name, email, degree, username, password, r_password, dob1, dob2, dob3, gender, phn):
		self.name = name
		self.email = email
		self.degree = degree
		self.username = username
		self.password = password
		self.r_password = r_password
		self.dob1 = dob1
		self.dob2 = dob2
		self.dob3 = dob3
		self.gender = gender
		self.phn = phn
	@app.route('/dregister', methods = ['GET', 'POST'])
	def new5():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['degree'] or not request.form['username'] or not request.form['password'] or not request.form['r_password'] or not request.form['dob1'] or not request.form['dob2'] or not request.form['dob3'] or not request.form['gender'] or not request.form['phn']:
				flash('Please enter all the fields', 'error')
			else:
				dreg = dregister(request.form['name'], request.form['email'], request.form['degree'], request.form['username'], request.form['password'], request.form['r_password'], request.form['dob1'], request.form['dob2'], request.form['dob3'], request.form['gender'], request.form['phn'])			 
				db.session.add(dreg)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('log'))
		return render_template('dreg.html')

@app.route('/login', methods=['POST','GET'])
def login():
	if request.method=='GET':
		return render_template('log.html')
	username = request.form['username']
	password = request.form['password']
	reg=register.query.filter_by(username=username,password=password).first()
	dreg=dregister.query.filter_by(username=username,password=password).first()
	if request.form['password'] == '1' and request.form['username'] == 'admin':
		return render_template("admin/adoc.html")
	if reg is None:
		return render_template("log.html")
	else:
		return redirect(url_for('details',name=username))
	if dreg is None:
		return render_template("log.html")
	else:
		return redirect(url_for('home.html'))

@app.route('/search_view', methods=['POST','GET'])
def search_view():
	if request.method=='GET':
		return render_template('search.html')
	search = request.form['search']
 	return redirect(url_for('search_details',name=search))

@app.route('/prediction_view', methods=['POST','GET'])
def prediction_view():
	if request.method=='GET':
		return render_template('prediction.html')
	prediction = request.form['prediction']
	return redirect(url_for('prediction_details',name=prediction))

@app.route('/status/<var>' , methods=['POST', 'GET'])
def status(var):
	demo=adoc.query.get(id=var)
	demo.status = 0
	db.session.commit()
	return redirect(url_for('vdoc'))	

class adoc(db.Model):
	id = db.Column('demo_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	degree = db.Column(db.String(100))
	email = db.Column(db.String(100))
	def __init__(self, name, degree, email):
		self.name = name
		self.degree = degree
		self.email = email
	@app.route('/adoc', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['degree'] or not request.form['email']:
				flash('Please enter all the fields', 'error')
			else:
				demo = adoc(request.form['name'], request.form['degree'] , request.form['email'])			 
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('adoc'))
		return render_template('adoc.html')

class ad(db.Model):
	id = db.Column('adis_id', db.Integer, primary_key = True)
	diseases_name = db.Column(db.String(100))
	symptoms = db.Column(db.String(100))
	def __init__(self,diseases_name, symptoms):
		self.diseases_name = diseases_name
		self.symptoms = symptoms
	@app.route('/ad', methods = ['GET', 'POST'])
	def new2():
		if request.method == 'POST':
			if not request.form['diseases_name'] or not request.form['symptoms']:
				flash('Please enter all the fields', 'error')
			else:
				adis = ad(request.form['diseases_name'], request.form['symptoms'])			 
				db.session.add(adis)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('ad'))
		return render_template('ad.html')

class feedback(db.Model):
	id = db.Column('feed_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	feedback = db.Column(db.String(100))
	def __init__(self,name,email,feedback):
		self.name = name
		self.email = email
		self.feedback = feedback
	@app.route('/feedback', methods = ['GET', 'POST'])
	def new3():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['feedback']:
				flash('Please enter all the fields', 'error')
			else:
				feed = feedback(request.form['name'], request.form['email'] , request.form['feedback'])			 
				db.session.add(feed)
				db.session.commit()
 				flash('Record was successfully added')
				return redirect(url_for('feedback'))
		return render_template('feedback.html')

class contact(db.Model):
	id = db.Column('contact1_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	subject = db.Column(db.String(100))
	message = db.Column(db.String(100))
	def __init__(self,name,email,subject,message):
		self.name = name
		self.email = email
		self.subject = subject
		self.message = message
	@app.route('/contact', methods = ['GET', 'POST'])
	def new4():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['subject'] or not request.form['message']:
				flash('Please enter all the fields', 'error')
			else:
				contact1 = contact(request.form['name'], request.form['email'], request.form['subject'], request.form['message'])			 
				db.session.add(contact1)
				db.session.commit()
 				flash('Record was successfully added')
				return redirect(url_for('contact'))
		return render_template('contact.html')

if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
