from flask import Flask, render_template, request, flash, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/e_health'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)

@app.route('/')
def index():
   return render_template('welcome_page.html')
@app.route('/login')
def log():
   return render_template('login.html')  
@app.route('/register')
def reg():
   return render_template('patient_registration.html')	
@app.route('/dregister')
def dreg():
   return render_template('doc_registration.html')						

@app.route('/adoc')
def add_doc():
   return render_template('admin/add_doc.html')
@app.route('/ad')
def add_disease():
   return render_template('admin/add_disease.html')
@app.route('/vdoc')
def vdoc():
   return render_template('admin/view_doc.html',add_doc=add_doc.query.all())
@app.route('/vd')
def vd():
   return render_template('admin/view_disease.html',add_disease=add_disease.query.all())
@app.route('/vp')
def vp():
   return render_template('admin/view_patient.html',patient_register=patient_register.query.all())
@app.route('/vpf')
def vdf():
   return render_template('admin/view_patient_feed.html',patient_feedback=patient_feedback.query.all())
@app.route('/vpc')
def vdc():
   return render_template('admin/view_patient_contact.html',patient_contact=patient_contact.query.all())
@app.route('/vf')
def vf():
   return render_template('admin/view_doc_feed.html',doc_feedback=doc_feedback.query.all())
@app.route('/vc')
def vc():
   return render_template('admin/view_doc_contact.html',doc_contact=doc_contact.query.all())

@app.route('/home')
def home():
   return render_template('user/patient_home.html')
@app.route('/details/<name>')
def patient_details(name):
   return render_template('user/patient_details.html',patient_register=patient_register.query.filter_by(username='%s'%name))
@app.route('/search')
def search():
   return render_template('user/doc_search.html')
@app.route('/search_details/<name>')
def search_details(name):
   return render_template('user/doc_search_view.html',add_doc=add_doc.query.filter_by(name='%s'%name))
@app.route('/m_app')
def m_app():
   return render_template('user/make_appoinment.html')
@app.route('/prediction')
def prediction():
   return render_template('user/disease_prediction.html')
@app.route('/prediction_details/<name>')
def prediction_details(name):
   return render_template('user/disease_prediction_view.html',add_disease=add_disease.query.filter_by(diseases_name='%s'%name))
@app.route('/rdoc')
def rdoc():
   return render_template('user/related_doc_view.html',doc_register=doc_register.query.all())
@app.route('/feedback')
def patient_feedback():
   return render_template('user/patient_feedback.html')
@app.route('/contact')
def patient_contact():
   return render_template('user/patient_contact.html')

@app.route('/dh')
def home1():
   return render_template('doctor/doc_home.html')
@app.route('/dd/<name>')
def doc_details(name):
   return render_template('doctor/doc_details.html',doc_register=doc_register.query.filter_by(username='%s'%name))
@app.route('/dr')
def record():
   return render_template('doctor/patient_rcrd.html',patient_register=patient_register.query.all())
@app.route('/df')
def doc_feedback():
   return render_template('doctor/doc_feedback.html')
@app.route('/dc')
def doc_contact():
   return render_template('doctor/doc_contact.html')

class patient_register(db.Model):
	id = db.Column('reg_id', db.Integer, primary_key = True)
	name = db.Column(db.String(200))
	email = db.Column(db.String(200))
	username = db.Column(db.String(200)) 
	password = db.Column(db.String(10))
	r_password = db.Column(db.String(10))
	dob1 = db.Column(db.String(100))
	dob2 = db.Column(db.String(100))
	dob3 = db.Column(db.String(100))
	gender = db.Column(db.String(10))
	phn = db.Column(db.String(100))
	def __init__(self, name, email, username, password, r_password, dob1, dob2, dob3, gender, phn):
		self.name = name
		self.email = email
		self.username = username
		self.password = password
		self.r_password = r_password
		self.dob1 = dob1
		self.dob2 = dob2
		self.dob3 = dob3
		self.gender = gender
		self.phn = phn
	@app.route('/register', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['r_password'] or not request.form['dob1'] or not request.form['dob2'] or not request.form['dob3'] or not request.form['gender'] or not request.form['phn']:
				flash('Please enter all the fields', 'error')
			else:
				reg = patient_register(request.form['name'], request.form['email'], request.form['username'], request.form['password'], request.form['r_password'], request.form['dob1'], request.form['dob2'], request.form['dob3'], request.form['gender'], request.form['phn'])			 
				db.session.add(reg)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('log'))
		return render_template('patient_registration.html')

class doc_register(db.Model):
	id = db.Column('dreg_id', db.Integer, primary_key = True)
	name = db.Column(db.String(200))
	email = db.Column(db.String(200))
	degree = db.Column(db.String(200))
	specialised = db.Column(db.String(200))
	username = db.Column(db.String(200)) 
	password = db.Column(db.String(10))
	r_password = db.Column(db.String(10))
	dob1 = db.Column(db.String(100))
	dob2 = db.Column(db.String(100))
	dob3 = db.Column(db.String(100))
	gender = db.Column(db.String(10))
	phn = db.Column(db.String(100))
	def __init__(self, name, email, degree, specialised, username, password, r_password, dob1, dob2, dob3, gender, phn):
		self.name = name
		self.email = email
		self.degree = degree
		self.specialised = specialised
		self.username = username
		self.password = password
		self.r_password = r_password
		self.dob1 = dob1
		self.dob2 = dob2
		self.dob3 = dob3
		self.gender = gender
		self.phn = phn
	@app.route('/dregister', methods = ['GET', 'POST'])
	def new5():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['degree'] or not request.form['specialised'] or not request.form['username'] or not request.form['password'] or not request.form['r_password'] or not request.form['dob1'] or not request.form['dob2'] or not request.form['dob3'] or not request.form['gender'] or not request.form['phn']:
				flash('Please enter all the fields', 'error')
			else:
				dreg = doc_register(request.form['name'], request.form['email'], request.form['degree'], request.form['specialised'], request.form['username'], request.form['password'], request.form['r_password'], request.form['dob1'], request.form['dob2'], request.form['dob3'], request.form['gender'], request.form['phn'])			 
				db.session.add(dreg)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('log'))
		return render_template('doc_registration.html')

@app.route('/login', methods=['POST','GET'])
def login():
	if request.method=='GET':
		return render_template('login.html')
	username = request.form['username']
	password = request.form['password']
	reg=patient_register.query.filter_by(username=username,password=password).first()
	dreg=doc_register.query.filter_by(username=username,password=password).first()
	if request.form['password'] == '1' and request.form['username'] == 'admin':
		return render_template("admin/add_doc.html")
	if reg is not None:
		return redirect(url_for('patient_details',name=username))
	elif dreg is not None:
		return redirect(url_for('doc_details',name=username))
	else:
		return render_template("login.html")

@app.route('/doc_search_view', methods=['POST','GET'])
def search_view():
	if request.method=='GET':
		return render_template('user/doc_search.html')
	search = request.form['search']
 	return redirect(url_for('search_details',name=search))

@app.route('/disease_prediction_view', methods=['POST','GET'])
def prediction_view():
	if request.method=='GET':
		return render_template('user/disease_prediction.html')
	prediction = request.form['prediction']
	return redirect(url_for('prediction_details',name=prediction))

@app.route('/status/<var>' , methods=['POST', 'GET'])
def status(var):
	demo=adoc.query.get(id=var)
	demo.status = 0
	db.session.commit()
	return redirect(url_for('view_doc'))	

class add_doc(db.Model):
	id = db.Column('demo_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	degree = db.Column(db.String(100))
	specialised = db.Column(db.String(100))
	phn = db.Column(db.String(100))
	def __init__(self, name, email, degree, specialised, phn):
		self.name = name
		self.email = email
		self.degree = degree
		self.specialised = specialised
		self.phn = phn
	@app.route('/add_doc', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['degree'] or not request.form['specialised'] or not request.form['phn']:
				flash('Please enter all the fields', 'error')
			else:
				demo = add_doc(request.form['name'], request.form['email'], request.form['degree'], request.form['specialised'], request.form['phn'])			 
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('add_doc'))
		return render_template('admin/add_doc.html')

class add_disease(db.Model):
	id = db.Column('adis_id', db.Integer, primary_key = True)
	diseases_name = db.Column(db.String(100))
	symptoms = db.Column(db.String(100))
	def __init__(self,diseases_name, symptoms):
		self.diseases_name = diseases_name
		self.symptoms = symptoms
	@app.route('/add_disease', methods = ['GET', 'POST'])
	def new2():
		if request.method == 'POST':
			if not request.form['diseases_name'] or not request.form['symptoms']:
				flash('Please enter all the fields', 'error')
			else:
				adis = add_disease(request.form['diseases_name'], request.form['symptoms'])			 
				db.session.add(adis)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('add_disease'))
		return render_template('admin/add_disease.html')

class patient_feedback(db.Model):
	id = db.Column('feed_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	feedback = db.Column(db.String(100))
	def __init__(self,name,email,feedback):
		self.name = name
		self.email = email
		self.feedback = feedback
	@app.route('/patient_feedback', methods = ['GET', 'POST'])
	def new3():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['feedback']:
				flash('Please enter all the fields', 'error')
			else:
				feed = patient_feedback(request.form['name'], request.form['email'] , request.form['feedback'])			 
				db.session.add(feed)
				db.session.commit()
 				flash('Record was successfully added')
				return redirect(url_for('patient_feedback'))
		return render_template('user/patient_feedback.html')

class patient_contact(db.Model):
	id = db.Column('contact1_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	subject = db.Column(db.String(100))
	message = db.Column(db.String(100))
	def __init__(self,name,email,subject,message):
		self.name = name
		self.email = email
		self.subject = subject
		self.message = message
	@app.route('/patient_contact', methods = ['GET', 'POST'])
	def new4():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['subject'] or not request.form['message']:
				flash('Please enter all the fields', 'error')
			else:
				contact1 = patient_contact(request.form['name'], request.form['email'], request.form['subject'], request.form['message'])			 
				db.session.add(contact1)
				db.session.commit()
 				flash('Record was successfully added')
				return redirect(url_for('patient_contact'))
		return render_template('user/patient_contact.html')

class doc_feedback(db.Model):
	id = db.Column('feed_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	feedback = db.Column(db.String(100))
	def __init__(self,name,email,feedback):
		self.name = name
		self.email = email
		self.feedback = feedback
	@app.route('/doc_feedback', methods = ['GET', 'POST'])
	def new6():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['feedback']:
				flash('Please enter all the fields', 'error')
			else:
				feed = doc_feedback(request.form['name'], request.form['email'] , request.form['feedback'])			 
				db.session.add(feed)
				db.session.commit()
 				flash('Record was successfully added')
				return redirect(url_for('doc_feedback'))
		return render_template('user/doc_feedback.html')

class doc_contact(db.Model):
	id = db.Column('contact1_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	subject = db.Column(db.String(100))
	message = db.Column(db.String(100))
	def __init__(self,name,email,subject,message):
		self.name = name
		self.email = email
		self.subject = subject
		self.message = message
	@app.route('/doc_contact', methods = ['GET', 'POST'])
	def new7():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['subject'] or not request.form['message']:
				flash('Please enter all the fields', 'error')
			else:
				contact1 = doc_contact(request.form['name'], request.form['email'], request.form['subject'], request.form['message'])			 
				db.session.add(contact1)
				db.session.commit()
 				flash('Record was successfully added')
				return redirect(url_for('doc_contact'))
		return render_template('doctor/doc_contact.html')
		
class make_appointment(db.Model):
	id = db.Column('m_app_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	subject = db.Column(db.String(100))
	message = db.Column(db.String(10000))
	def __init__(self,name,email,subject,message):
		self.name = name
		self.email = email
		self.subject = subject
		self.message = message
	@app.route('/m_app', methods = ['GET', 'POST'])
	def new8():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['subject'] or not request.form['message']:
				flash('Please enter all the fields', 'error')
			else:
				m_app = make_appointment(request.form['name'], request.form['email'], request.form['subject'], request.form['message'])			 
				db.session.add(m_app)
				db.session.commit()
 				flash('Record was successfully added')
				return redirect(url_for('m_app'))
		return render_template('user/make_appointment.html')

if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
